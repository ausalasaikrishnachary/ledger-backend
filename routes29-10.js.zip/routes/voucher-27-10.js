const express = require('express');
const router = express.Router();
const db = require('../db');

// Get next invoice number
router.get("/next-invoice-number", async (req, res) => {
  try {
    const query = `
      SELECT MAX(CAST(SUBSTRING(InvoiceNumber, 4) AS UNSIGNED)) as maxNumber 
      FROM voucher 
      WHERE TransactionType = 'Sales' 
      AND InvoiceNumber LIKE 'INV%'
    `;
    
    db.query(query, (err, results) => {
      if (err) {
        console.error('Error fetching next invoice number:', err);
        return res.status(500).send({ error: 'Failed to get next invoice number' });
      }
      
      let nextNumber = 1;
      if (results[0].maxNumber !== null && !isNaN(results[0].maxNumber)) {
        nextNumber = parseInt(results[0].maxNumber) + 1;
      }
      
      const nextInvoiceNumber = `INV${nextNumber.toString().padStart(3, '0')}`;
      
      res.send({ nextInvoiceNumber });
    });
  } catch (error) {
    console.error('Error in next-invoice-number:', error);
    res.status(500).send({ error: 'Internal server error' });
  }
});

// Create Sales Transaction and Update Stock - FIXED invoice number handling
router.post("/transaction", (req, res) => {
  const transactionData = req.body;
  console.log('Received transaction data:', transactionData);
  
  // Start transaction
  db.getConnection((err, connection) => {
    if (err) {
      console.error('Database connection error:', err);
      return res.status(500).send({ error: 'Database connection failed' });
    }

    connection.beginTransaction((err) => {
      if (err) {
        connection.release();
        console.error('Transaction begin error:', err);
        return res.status(500).send({ error: 'Transaction failed to start' });
      }

      // Helper function for promises
      const queryPromise = (sql, params = []) => {
        return new Promise((resolve, reject) => {
          connection.query(sql, params, (err, results) => {
            if (err) reject(err);
            else resolve(results);
          });
        });
      };

      const processTransaction = async () => {
        try {
          // First, get the next available VoucherID
          let nextVoucherId;
          try {
            const maxIdResult = await queryPromise("SELECT COALESCE(MAX(VoucherID), 0) + 1 as nextId FROM voucher");
            nextVoucherId = maxIdResult[0].nextId;
            console.log('Next available VoucherID:', nextVoucherId);
          } catch (maxIdError) {
            console.error('Error getting next VoucherID:', maxIdError);
            nextVoucherId = 1; // Fallback to 1
          }

          // Calculate GST breakdown
          const totalCGST = parseFloat(transactionData.totalCGST) || 0;
          const totalSGST = parseFloat(transactionData.totalSGST) || 0;
          const totalIGST = parseFloat(transactionData.totalIGST) || 0;
          const taxType = transactionData.taxType || "CGST/SGST";

          // Parse batch details from JSON string
          let batchDetailsJson = '[]';
          try {
            if (transactionData.batchDetails) {
              batchDetailsJson = typeof transactionData.batchDetails === 'string' 
                ? transactionData.batchDetails 
                : JSON.stringify(transactionData.batchDetails);
            }
          } catch (error) {
            console.error('Error parsing batch details:', error);
            batchDetailsJson = '[]';
          }

          // Use the provided invoice number or generate a default
          const invoiceNumber = transactionData.invoiceNumber || 'INV001';
          console.log('Using invoice number:', invoiceNumber);

          // 1. Insert into Voucher table with explicit VoucherID and BatchDetails
          const voucherSql = `INSERT INTO voucher SET ?`;
          
          // Calculate totals safely
          const totalQty = transactionData.items.reduce((sum, item) => {
            return sum + (parseFloat(item.quantity) || 0);
          }, 0);

          // Only include columns that exist in the Voucher table
          const voucherData = {
            VoucherID: nextVoucherId,
            TransactionType: 'Sales',
            VchNo: invoiceNumber, // Use the actual invoice number
            InvoiceNumber: transactionData.invoiceNumber || 'INV001',
            Date: transactionData.invoiceDate || new Date().toISOString().split('T')[0],
            PaymentTerms: 'Immediate',
            Freight: 0,
            TotalQty: totalQty,
            TotalPacks: transactionData.items.length,
            TotalQty1: totalQty,
            TaxAmount: parseFloat(transactionData.totalGST) || 0,
            Subtotal: parseFloat(transactionData.taxableAmount) || 0,
            BillSundryAmount: 0,
            TotalAmount: parseFloat(transactionData.grandTotal) || 0,
            ChequeNo: null,
            ChequeDate: null,
            BankName: null,
            AccountID: transactionData.selectedSupplierId || null,
            AccountName: transactionData.supplierInfo?.businessName || '',
            PartyID: transactionData.selectedSupplierId || null,
            PartyName: transactionData.supplierInfo?.name || '',
            BasicAmount: parseFloat(transactionData.taxableAmount) || 0,
            ValueOfGoods: parseFloat(transactionData.taxableAmount) || 0,
            EntryDate: new Date(),
            SGSTPercentage: taxType === "CGST/SGST" ? (totalSGST > 0 ? 50 : 0) : 0,
            CGSTPercentage: taxType === "CGST/SGST" ? (totalCGST > 0 ? 50 : 0) : 0,
            IGSTPercentage: taxType === "IGST" ? 100 : 0,
            SGSTAmount: totalSGST,
            CGSTAmount: totalCGST,
            IGSTAmount: totalIGST,
            TaxSystem: 'GST',
            BatchDetails: batchDetailsJson
          };

          console.log('Inserting voucher data with VoucherID:', nextVoucherId, 'Invoice No:', invoiceNumber);
          console.log('GST Breakdown - CGST:', totalCGST, 'SGST:', totalSGST, 'IGST:', totalIGST);

          const voucherResult = await queryPromise(voucherSql, voucherData);
          const voucherId = voucherResult.insertId || nextVoucherId;
          console.log('Voucher created with ID:', voucherId);

          // 2. Process each item and update stock
          for (const [index, item] of transactionData.items.entries()) {
            console.log(`Processing item ${index + 1}:`, item);

            // Find product by name
            const productResult = await queryPromise(
              "SELECT id, balance_stock, stock_out, stock_in, opening_stock FROM products WHERE goods_name = ?",
              [item.product]
            );

            if (productResult.length === 0) {
              throw new Error(`Product not found: ${item.product}`);
            }

            const product = productResult[0];
            const productId = product.id;
            const quantity = parseFloat(item.quantity) || 0;

            console.log(`Product found: ID=${productId}, Current balance=${product.balance_stock}, Quantity to deduct=${quantity}`);

            // Check if sufficient stock is available
            const currentBalance = parseFloat(product.balance_stock) || 0;
            if (currentBalance < quantity) {
              throw new Error(`Insufficient stock for ${item.product}. Available: ${currentBalance}, Required: ${quantity}`);
            }

            // Calculate new stock values
            const currentStockOut = parseFloat(product.stock_out) || 0;
            const newStockOut = currentStockOut + quantity;
            const newBalanceStock = currentBalance - quantity;

            console.log(`Stock calculation: Opening=${product.opening_stock}, StockOut=${currentStockOut} -> ${newStockOut}, Balance=${currentBalance} -> ${newBalanceStock}`);

            // Update product stock in products table
            await queryPromise(
              "UPDATE products SET stock_out = ?, balance_stock = ? WHERE id = ?",
              [newStockOut, newBalanceStock, productId]
            );

            console.log(`Updated product ${productId}: stock_out=${newStockOut}, balance_stock=${newBalanceStock}`);

            // Handle stock table - Create new stock record for this transaction
            const stockData = {
              product_id: productId,
              price_per_unit: parseFloat(item.price) || 0,
              opening_stock: parseFloat(product.opening_stock) || 0,
              stock_in: 0,
              stock_out: quantity,
              balance_stock: newBalanceStock,
              batch_number: item.batch || null,
              voucher_id: voucherId,
              date: new Date()
            };

            await queryPromise("INSERT INTO stock SET ?", stockData);
            console.log(`Created new stock record for product ${productId} with stock_out=${quantity}, batch=${item.batch}, voucher=${voucherId}`);

            // Update batch quantity if batch is selected
            if (item.batch) {
              const batchResult = await queryPromise(
                "SELECT id, quantity FROM batches WHERE product_id = ? AND batch_number = ?",
                [productId, item.batch]
              );

              if (batchResult.length > 0) {
                const batch = batchResult[0];
                const currentBatchQty = parseFloat(batch.quantity) || 0;
                
                if (currentBatchQty >= quantity) {
                  const newBatchQty = currentBatchQty - quantity;
                  await queryPromise(
                    "UPDATE batches SET quantity = ? WHERE id = ?",
                    [newBatchQty, batch.id]
                  );
                  console.log(`Updated batch ${item.batch} for product ${productId}: ${currentBatchQty} -> ${newBatchQty}`);
                } else {
                  throw new Error(`Insufficient batch quantity for ${item.batch}. Available: ${currentBatchQty}, Required: ${quantity}`);
                }
              } else {
                console.warn(`Batch ${item.batch} not found for product ${productId}`);
              }
            }
          }

          // Commit transaction
          connection.commit((err) => {
            if (err) {
              console.error('Commit error:', err);
              return connection.rollback(() => {
                connection.release();
                res.status(500).send({ error: 'Transaction commit failed', details: err.message });
              });
            }
            connection.release();
            console.log('Transaction completed successfully');
            res.send({
              message: "Transaction completed successfully",
              voucherId: voucherId,
              invoiceNumber: invoiceNumber,
              stockUpdated: true,
              taxType: taxType,
              gstBreakdown: {
                cgst: totalCGST,
                sgst: totalSGST,
                igst: totalIGST
              },
              batchDetails: JSON.parse(batchDetailsJson)
            });
          });

        } catch (error) {
          console.error('Transaction error:', error);
          connection.rollback(() => {
            connection.release();
            
            // Handle specific duplicate key error
            if (error.code === 'ER_DUP_ENTRY') {
              res.status(500).send({ 
                error: 'Database error: Duplicate entry detected. Please contact administrator to fix voucher table auto-increment.',
                details: 'VoucherID primary key conflict',
                code: 'DUPLICATE_KEY_ERROR'
              });
            } else {
              res.status(500).send({ 
                error: 'Transaction failed', 
                details: error.message,
                code: error.code
              });
            }
          });
        }
      };

      processTransaction();
    });
  });
});

// Create Purchase Transaction and Update Stock
router.post("/purchase-transaction", (req, res) => {
  const transactionData = req.body;
  console.log('Received purchase transaction data:', transactionData);
  
  db.getConnection((err, connection) => {
    if (err) {
      console.error('Database connection error:', err);
      return res.status(500).send({ error: 'Database connection failed' });
    }

    connection.beginTransaction((err) => {
      if (err) {
        connection.release();
        console.error('Transaction begin error:', err);
        return res.status(500).send({ error: 'Transaction failed to start' });
      }

      const queryPromise = (sql, params = []) => {
        return new Promise((resolve, reject) => {
          connection.query(sql, params, (err, results) => {
            if (err) reject(err);
            else resolve(results);
          });
        });
      };

      const processPurchaseTransaction = async () => {
        try {
          // Get the next available VoucherID
          let nextVoucherId;
          try {
            const maxIdResult = await queryPromise("SELECT COALESCE(MAX(VoucherID), 0) + 1 as nextId FROM voucher");
            nextVoucherId = maxIdResult[0].nextId;
            console.log('Next available VoucherID:', nextVoucherId);
          } catch (maxIdError) {
            console.error('Error getting next VoucherID:', maxIdError);
            nextVoucherId = 1;
          }

          // Calculate GST breakdown
          const totalCGST = parseFloat(transactionData.totalCGST) || 0;
          const totalSGST = parseFloat(transactionData.totalSGST) || 0;
          const totalIGST = parseFloat(transactionData.totalIGST) || 0;
          const taxType = transactionData.taxType || "CGST/SGST";

          // Parse batch details from JSON string
          let batchDetailsJson = '[]';
          try {
            if (transactionData.batchDetails) {
              batchDetailsJson = typeof transactionData.batchDetails === 'string' 
                ? transactionData.batchDetails 
                : JSON.stringify(transactionData.batchDetails);
            }
          } catch (error) {
            console.error('Error parsing batch details:', error);
            batchDetailsJson = '[]';
          }

          // 1. Insert into Voucher table for purchase
          const voucherSql = `INSERT INTO voucher SET ?`;
          
          const totalQty = transactionData.items.reduce((sum, item) => {
            return sum + (parseFloat(item.quantity) || 0);
          }, 0);

          const voucherData = {
            VoucherID: nextVoucherId,
            TransactionType: 'Purchase',
            VchNo: transactionData.invoiceNumber || 'PUR001',
            Date: transactionData.invoiceDate || new Date().toISOString().split('T')[0],
            PaymentTerms: 'Immediate',
            Freight: 0,
            TotalQty: totalQty,
            TotalPacks: transactionData.items.length,
            TotalQty1: totalQty,
            TaxAmount: parseFloat(transactionData.totalGST) || 0,
            Subtotal: parseFloat(transactionData.taxableAmount) || 0,
            BillSundryAmount: 0,
            TotalAmount: parseFloat(transactionData.grandTotal) || 0,
            ChequeNo: null,
            ChequeDate: null,
            BankName: null,
            AccountID: transactionData.selectedSupplierId || null,
            AccountName: transactionData.supplierInfo?.businessName || '',
            PartyID: transactionData.selectedSupplierId || null,
            PartyName: transactionData.supplierInfo?.name || '',
            BasicAmount: parseFloat(transactionData.taxableAmount) || 0,
            ValueOfGoods: parseFloat(transactionData.taxableAmount) || 0,
            EntryDate: new Date(),
            SGSTPercentage: taxType === "CGST/SGST" ? (totalSGST > 0 ? 50 : 0) : 0,
            CGSTPercentage: taxType === "CGST/SGST" ? (totalCGST > 0 ? 50 : 0) : 0,
            IGSTPercentage: taxType === "IGST" ? 100 : 0,
            SGSTAmount: totalSGST,
            CGSTAmount: totalCGST,
            IGSTAmount: totalIGST,
            TaxSystem: 'GST',
            BatchDetails: batchDetailsJson
          };

          console.log('Inserting purchase voucher data with VoucherID:', nextVoucherId);

          const voucherResult = await queryPromise(voucherSql, voucherData);
          const voucherId = voucherResult.insertId || nextVoucherId;
          console.log('Purchase Voucher created with ID:', voucherId);

          // 2. Process each item and update stock for purchase
          for (const [index, item] of transactionData.items.entries()) {
            console.log(`Processing purchase item ${index + 1}:`, item);

            // Find product by name
            const productResult = await queryPromise(
              "SELECT id, balance_stock, stock_out, stock_in, opening_stock FROM products WHERE goods_name = ?",
              [item.product]
            );

            if (productResult.length === 0) {
              throw new Error(`Product not found: ${item.product}`);
            }

            const product = productResult[0];
            const productId = product.id;
            const quantity = parseFloat(item.quantity) || 0;

            console.log(`Product found: ID=${productId}, Current balance=${product.balance_stock}, Quantity to add=${quantity}`);

            // Calculate new stock values for purchase (INCREASE stock)
            const currentStockIn = parseFloat(product.stock_in) || 0;
            const currentBalance = parseFloat(product.balance_stock) || 0;
            const newStockIn = currentStockIn + quantity;
            const newBalanceStock = currentBalance + quantity; // INCREASE balance stock

            console.log(`Purchase stock calculation: Opening=${product.opening_stock}, StockIn=${currentStockIn} -> ${newStockIn}, Balance=${currentBalance} -> ${newBalanceStock}`);

            // Update product stock in products table
            await queryPromise(
              "UPDATE products SET stock_in = ?, balance_stock = ? WHERE id = ?",
              [newStockIn, newBalanceStock, productId]
            );

            console.log(`Updated product ${productId}: stock_in=${newStockIn}, balance_stock=${newBalanceStock}`);

            // Handle stock table - Create new stock record for this purchase transaction
            // FIXED: Include batch_number and voucher_id in stock table
            const stockData = {
              product_id: productId,
              price_per_unit: parseFloat(item.price) || 0,
              opening_stock: parseFloat(product.opening_stock) || 0,
              stock_in: quantity, // This is purchase, so stock_in increases
              stock_out: 0,
              balance_stock: newBalanceStock,
              batch_number: item.batch || null, // Store batch number
              voucher_id: voucherId, // Store voucher ID (invoice number)
              date: new Date()
            };

            await queryPromise("INSERT INTO stock SET ?", stockData);
            console.log(`Created new purchase stock record for product ${productId} with stock_in=${quantity}, batch=${item.batch}, voucher=${voucherId}`);

            // Handle batch - Create or update batch for purchase
            if (item.batch) {
              // Check if batch already exists
              const batchResult = await queryPromise(
                "SELECT id, quantity FROM batches WHERE product_id = ? AND batch_number = ?",
                [productId, item.batch]
              );

              if (batchResult.length > 0) {
                // Update existing batch
                const batch = batchResult[0];
                const currentBatchQty = parseFloat(batch.quantity) || 0;
                const newBatchQty = currentBatchQty + quantity; // INCREASE batch quantity
                
                await queryPromise(
                  "UPDATE batches SET quantity = ?, updated_at = ? WHERE id = ?",
                  [newBatchQty, new Date(), batch.id]
                );
                console.log(`Updated batch ${item.batch} for product ${productId}: ${currentBatchQty} -> ${newBatchQty}`);
              } else {
                // Create new batch
                const batchData = {
                  product_id: productId,
                  batch_number: item.batch,
                  quantity: quantity,
                  manufacturing_date: new Date(),
                  expiry_date: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000), // 1 year from now
                  purchase_price: parseFloat(item.price) || 0,
                  created_at: new Date(),
                  updated_at: new Date()
                };
                
                await queryPromise("INSERT INTO batches SET ?", batchData);
                console.log(`Created new batch ${item.batch} for product ${productId} with quantity=${quantity}`);
              }
            }
          }

          // Commit transaction
          connection.commit((err) => {
            if (err) {
              console.error('Commit error:', err);
              return connection.rollback(() => {
                connection.release();
                res.status(500).send({ error: 'Transaction commit failed', details: err.message });
              });
            }
            connection.release();
            console.log('Purchase transaction completed successfully');
            res.send({
              message: "Purchase transaction completed successfully",
              voucherId: voucherId,
              stockUpdated: true,
              taxType: taxType,
              gstBreakdown: {
                cgst: totalCGST,
                sgst: totalSGST,
                igst: totalIGST
              },
              batchDetails: JSON.parse(batchDetailsJson)
            });
          });

        } catch (error) {
          console.error('Purchase transaction error:', error);
          connection.rollback(() => {
            connection.release();
            
            if (error.code === 'ER_DUP_ENTRY') {
              res.status(500).send({ 
                error: 'Database error: Duplicate entry detected.',
                details: 'VoucherID primary key conflict',
                code: 'DUPLICATE_KEY_ERROR'
              });
            } else {
              res.status(500).send({ 
                error: 'Purchase transaction failed', 
                details: error.message,
                code: error.code
              });
            }
          });
        }
      };

      processPurchaseTransaction();
    });
  });
});

// transactions.js route file
router.get("/transactions/:id", (req, res) => {
  const query = `
    SELECT 
      v.*, 
      JSON_UNQUOTE(BatchDetails) as batch_details,
      a.billing_address_line1,
      a.billing_address_line2,
      a.billing_city,
      a.billing_pin_code,
      a.billing_state,
      a.shipping_address_line1,
      a.shipping_address_line2,
      a.shipping_city,
      a.shipping_pin_code,
      a.shipping_state,
      a.gstin
    FROM voucher v
    LEFT JOIN accounts a ON v.PartyID = a.id
    WHERE v.VoucherID = ?
  `;
  
  db.query(query, [req.params.id], (err, results) => {
    if (err) {
      console.error('Error fetching transaction:', err);
      return res.status(500).json({
        success: false,
        message: 'Database error',
        error: err.message
      });
    }
    
    if (results.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Transaction not found'
      });
    }
    
    const transaction = results[0];
    
    // Parse batch details from JSON string with better error handling
    try {
      if (transaction.batch_details) {
        // Handle both stringified JSON and already parsed JSON
        if (typeof transaction.batch_details === 'string') {
          transaction.batch_details = JSON.parse(transaction.batch_details);
        }
        // If it's already an object, keep it as is
      } else {
        transaction.batch_details = [];
      }
    } catch (error) {
      console.error('Error parsing batch details:', error);
      console.log('Raw batch_details:', transaction.batch_details);
      transaction.batch_details = [];
    }
    
    // Log for debugging
    console.log('Transaction data:', {
      VoucherID: transaction.VoucherID,
      CGSTAmount: transaction.CGSTAmount,
      SGSTAmount: transaction.SGSTAmount,
      IGSTAmount: transaction.IGSTAmount,
      batch_details_length: transaction.batch_details?.length
    });
    
    res.json({
      success: true,
      data: transaction
    });
  });
});

// Get all transactions with batch details
router.get("/transactions", (req, res) => {
  const query = "SELECT *, JSON_UNQUOTE(BatchDetails) as batch_details FROM voucher ORDER BY VoucherID DESC";
  
  db.query(query, (err, results) => {
    if (err) {
      console.error('Error fetching transactions:', err);
      return res.status(500).send(err);
    }
    
    // Parse batch details for each transaction
    results.forEach(transaction => {
      try {
        if (transaction.batch_details) {
          transaction.batch_details = JSON.parse(transaction.batch_details);
        } else {
          transaction.batch_details = [];
        }
      } catch (error) {
        console.error('Error parsing batch details for transaction:', transaction.VoucherID, error);
        transaction.batch_details = [];
      }
    });
    
    res.send(results);
  });
});

// Get stock history for a product with batch and voucher details
router.get("/stock-history/:productId", (req, res) => {
  const productId = req.params.productId;
  
  const query = `
    SELECT s.*, p.goods_name, v.VchNo as invoice_number, v.TransactionType
    FROM stock s 
    JOIN products p ON s.product_id = p.id 
    LEFT JOIN voucher v ON s.voucher_id = v.VoucherID
    WHERE s.product_id = ? 
    ORDER BY s.date DESC, s.id DESC
  `;

  db.query(query, [productId], (err, results) => {
    if (err) {
      console.error('Error fetching stock history:', err);
      return res.status(500).send(err);
    }
    res.send(results);
  });
});

// Get current stock status for all products
router.get("/stock-status", (req, res) => {
  const query = `
    SELECT 
      id,
      goods_name,
      opening_stock,
      stock_in,
      stock_out,
      balance_stock,
      (opening_stock + stock_in - stock_out) as calculated_balance
    FROM products 
    ORDER BY goods_name
  `;

  db.query(query, (err, results) => {
    if (err) {
      console.error('Error fetching stock status:', err);
      return res.status(500).send(err);
    }
    res.send(results);
  });
});

// Get purchase transactions
router.get("/purchase-transactions", (req, res) => {
  db.query("SELECT * FROM voucher WHERE TransactionType = 'Purchase' ORDER BY VoucherID DESC", (err, results) => {
    if (err) {
      console.error('Error fetching purchase transactions:', err);
      return res.status(500).send(err);
    }
    res.send(results);
  });
});

// Get single purchase transaction
router.get("/purchase-transactions/:id", (req, res) => {
  db.query("SELECT * FROM voucher WHERE VoucherID = ? AND TransactionType = 'Purchase'", [req.params.id], (err, results) => {
    if (err) {
      console.error('Error fetching purchase transaction:', err);
      return res.status(500).send(err);
    }
    res.send(results[0] || {});
  });
});

// Get stock status with purchase history
router.get("/purchase-stock-status", (req, res) => {
  const query = `
    SELECT 
      p.id,
      p.goods_name,
      p.opening_stock,
      p.stock_in,
      p.stock_out,
      p.balance_stock,
      (p.opening_stock + p.stock_in - p.stock_out) as calculated_balance,
      COUNT(DISTINCT b.id) as batch_count
    FROM products p
    LEFT JOIN batches b ON p.id = b.product_id
    GROUP BY p.id
    ORDER BY p.goods_name
  `;

  db.query(query, (err, results) => {
    if (err) {
      console.error('Error fetching purchase stock status:', err);
      return res.status(500).send(err);
    }
    res.send(results);
  });
});

// Health check endpoint
router.get("/health", (req, res) => {
  res.send({ status: "OK", message: "Transaction service is running" });
});

// Check Voucher table status
router.get("/voucher-status", (req, res) => {
  const queries = [
    "SHOW COLUMNS FROM voucher LIKE 'VoucherID'",
    "SHOW COLUMNS FROM voucher LIKE 'BatchDetails'",
    "SELECT MAX(VoucherID) as maxId FROM Voucher",
    "SHOW TABLE STATUS LIKE 'voucher'"
  ];

  db.query(queries.join(';'), (err, results) => {
    if (err) {
      console.error('Error checking voucher status:', err);
      return res.status(500).send(err);
    }
    
    res.send({
      voucherIdColumn: results[0][0],
      batchDetailsColumn: results[1][0],
      maxId: results[2][0],
      tableStatus: results[3][0]
    });
  });
});

// Check Stock table structure
router.get("/stock-structure", (req, res) => {
  const query = "SHOW COLUMNS FROM stock";
  
  db.query(query, (err, results) => {
    if (err) {
      console.error('Error checking stock structure:', err);
      return res.status(500).send(err);
    }
    
    res.send(results);
  });
});



// Get last invoice number
// router.get("/transactions/last-invoice", (req, res) => {
//   const query = "SELECT VchNo FROM Voucher WHERE TransactionType = 'Sales' ORDER BY VoucherID DESC LIMIT 1";
  
//   db.query(query, (err, results) => {
//     if (err) {
//       console.error('Error fetching last invoice:', err);
//       return res.status(500).send(err);
//     }
    
//     if (results.length === 0) {
//       return res.send({ lastInvoiceNumber: null });
//     }
    
//     res.send({ lastInvoiceNumber: results[0].VchNo });
//   });
// });



// Get last invoice number
router.get("/last-invoice", (req, res) => {
  const query = "SELECT VchNo FROM voucher WHERE TransactionType = 'Sales' ORDER BY VoucherID DESC LIMIT 1";
  
  db.query(query, (err, results) => {
    if (err) {
      console.error('Error fetching last invoice number:', err);
      return res.status(500).send(err);
    }
    
    if (results.length === 0) {
      return res.send({ lastInvoiceNumber: null });
    }
    
    res.send({ lastInvoiceNumber: results[0].VchNo });
  });
});


router.post('/receipts', async (req, res) => {
  let connection;
  try {
    // Get DB connection
    connection = await new Promise((resolve, reject) => {
      db.getConnection((err, conn) => {
        if (err) reject(err);
        else resolve(conn);
      });
    });

    // Start transaction
    await new Promise((resolve, reject) => {
      connection.beginTransaction(err => {
        if (err) reject(err);
        else resolve();
      });
    });

    const {
      receipt_number,
      retailer_id,
      retailer_name,
      amount,
      currency,
      payment_method,
      receipt_date,
      note,
      bank_name,
      transaction_date,
      reconciliation_option,
      invoice_number
    } = req.body;

    // Validate receipt_number
    if (!receipt_number || !receipt_number.match(/^REC\d+$/)) {
      throw new Error('Invalid receipt number format');
    }

    // Check if receipt number already exists
    const existingReceipt = await new Promise((resolve, reject) => {
      connection.execute(
        `SELECT receipt_number FROM receipts WHERE receipt_number = ?`,
        [receipt_number],
        (err, results) => {
          if (err) reject(err);
          else resolve(results[0]);
        }
      );
    });

    if (existingReceipt) {
      throw new Error(`Receipt number ${receipt_number} already exists`);
    }

    const receiptAmount = parseFloat(amount || 0);

    // Step 1: Insert receipt in receipts table
    const receiptResult = await new Promise((resolve, reject) => {
      connection.execute(
        `INSERT INTO receipts (
          receipt_number, retailer_id, amount, currency, payment_method,
          receipt_date, note, bank_name, transaction_date, reconciliation_option
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          receipt_number,
          retailer_id || null,
          receiptAmount,
          currency || 'INR',
          payment_method || 'Direct Deposit',
          receipt_date || new Date(),
          note || '',
          bank_name || '',
          transaction_date || null,
          reconciliation_option || 'Do Not Reconcile',
        ],
        (err, results) => {
          if (err) reject(err);
          else resolve(results);
        }
      );
    });

    // Step 2: Apply receipt to existing Sales vouchers
    if (retailer_id) {
      let voucherQuery = `SELECT * FROM voucher WHERE PartyID = ? AND TransactionType='Sales'`;
      const queryParams = [retailer_id];

      if (invoice_number) {
        voucherQuery += ` AND InvoiceNumber = ?`;
        queryParams.push(invoice_number);
      }

      voucherQuery += ` ORDER BY Date ASC, VoucherID ASC`;

      const vouchers = await new Promise((resolve, reject) => {
        connection.execute(voucherQuery, queryParams, (err, results) => {
          if (err) reject(err);
          else resolve(results);
        });
      });

      if (vouchers && vouchers.length > 0) {
        let remainingAmount = receiptAmount;
        const currentDate = new Date();

        // Get previous receipt balance to calculate current balance
        const previousReceipts = await new Promise((resolve, reject) => {
          connection.execute(
            `SELECT * FROM voucher WHERE PartyID = ? AND TransactionType='Receipt' ORDER BY VoucherID DESC LIMIT 1`,
            [retailer_id],
            (err, results) => {
              if (err) reject(err);
              else resolve(results);
            }
          );
        });

        let previousBalance = 0;
        if (previousReceipts && previousReceipts.length > 0) {
          previousBalance = parseFloat(previousReceipts[0].balance_amount || 0);
        } else {
          // If no previous receipts, use sales total amount as starting balance
          previousBalance = parseFloat(vouchers[0].TotalAmount || 0);
        }

        for (const voucher of vouchers) {
          if (remainingAmount <= 0) break;

          const totalAmount = parseFloat(voucher.TotalAmount || 0);
          
          // Calculate current balance based on previous receipt balance
          const currentBalance = previousBalance;
          const amountToApply = Math.min(remainingAmount, currentBalance);
          if (amountToApply <= 0) continue;

          remainingAmount -= amountToApply;
          const updatedBalanceAmount = currentBalance - amountToApply;

          // FIXED: DO NOT update sales voucher at all - keep it original
          // No UPDATE query for sales voucher

          // FIXED: Create receipt entry with cumulative calculations
          await new Promise((resolve, reject) => {
            connection.execute(
              `INSERT INTO voucher (
                TransactionType, VchNo, InvoiceNumber, Date, PaymentTerms, Freight,
                TotalQty, TotalPacks, TotalQty1, TaxAmount, Subtotal, BillSundryAmount,
                TotalAmount, ChequeNo, ChequeDate, BankName, AccountID, AccountName,
                PartyID, PartyName, BasicAmount, ValueOfGoods, EntryDate,
                SGSTPercentage, CGSTPercentage, IGSTPercentage, SGSTAmount, CGSTAmount, IGSTAmount,
                TaxSystem, BatchDetails, paid_amount, balance_amount, receipt_number, status, paid_date
              ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
              [
                'Receipt',
                receipt_number,
                voucher.InvoiceNumber,
                currentDate,
                'Immediate',
                0.00,
                0.00,
                0,
                0,
                0.00,
                amountToApply,
                0.00,
                currentBalance, // TotalAmount = previous balance (not amount paid)
                null,
                null,
                bank_name || '',
                voucher.AccountID,
                voucher.AccountName,
                voucher.PartyID,
                retailer_name || voucher.PartyName,
                amountToApply,
                amountToApply,
                currentDate,
                0.00,
                0.00,
                0.00,
                0.00,
                0.00,
                0.00,
                'GST',
                '[]',
                amountToApply, // paid_amount = amount paid in this receipt
                updatedBalanceAmount, // balance_amount = remaining balance after this payment
                receipt_number,
                updatedBalanceAmount <= 0.01 ? 'Paid' : 'Partial',
                currentDate
              ],
              (err) => {
                if (err) reject(err);
                else resolve();
              }
            );
          });

          // Update previous balance for next iteration
          previousBalance = updatedBalanceAmount;
        }

        // If leftover amount, create advance payment row
        if (remainingAmount > 0) {
          await new Promise((resolve, reject) => {
            connection.execute(
              `INSERT INTO voucher (
                TransactionType, VchNo, Date, TotalAmount, BankName,
                PartyID, PartyName, BasicAmount, ValueOfGoods, EntryDate,
                paid_amount, balance_amount, receipt_number, status, paid_date
              ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
              [
                'Receipt',
                receipt_number,
                currentDate,
                previousBalance, // Show previous balance as TotalAmount
                bank_name,
                retailer_id,
                retailer_name,
                remainingAmount,
                remainingAmount,
                currentDate,
                remainingAmount,
                0,
                receipt_number,
                'Paid',
                currentDate
              ],
              (err) => {
                if (err) reject(err);
                else resolve();
              }
            );
          });
        }
      } else {
        // No sales vouchers found: simple receipt entry (advance payment)
        await new Promise((resolve, reject) => {
          connection.execute(
            `INSERT INTO voucher (
              TransactionType, VchNo, Date, TotalAmount, BankName,
              PartyID, PartyName, BasicAmount, ValueOfGoods, EntryDate,
              paid_amount, balance_amount, receipt_number, status, paid_date
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
              'Receipt',
              receipt_number,
              new Date(),
              receiptAmount,
              bank_name,
              retailer_id,
              retailer_name,
              receiptAmount,
              receiptAmount,
              new Date(),
              receiptAmount,
              0,
              receipt_number,
              'Paid',
              new Date()
            ],
            (err) => {
              if (err) reject(err);
              else resolve();
            }
          );
        });
      }
    }

    // Commit transaction
    await new Promise((resolve, reject) => {
      connection.commit(err => {
        if (err) reject(err);
        else resolve();
      });
    });

    res.status(201).json({
      id: receiptResult.insertId,
      message: 'Receipt created and applied to vouchers successfully',
      receipt_number
    });

  } catch (error) {
    if (connection) {
      await new Promise(resolve => connection.rollback(() => resolve()));
    }
    console.error('Error in create receipt route:', error);
    if (error.code === 'ER_DUP_ENTRY') {
      return res.status(400).json({ error: 'VoucherID must be AUTO_INCREMENT in voucher table' });
    }
    res.status(500).json({ error: error.message || 'Failed to create receipt' });
  } finally {
    if (connection) connection.release();
  }
});



module.exports = router;